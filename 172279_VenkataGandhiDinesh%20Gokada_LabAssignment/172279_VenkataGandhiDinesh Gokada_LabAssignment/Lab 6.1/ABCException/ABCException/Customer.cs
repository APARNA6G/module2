﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCException
{
    class Customer
    {
        private int CustomerId1;

        public int CustomerId
        {
            get { return CustomerId; }
            set { CustomerId = value; }
        }

        private string CustomerName1;

        public string CustomerName
        {
            get { return CustomerName; }
            set { CustomerName = value; }
        }

        private string Address;

        public string Address1
        {
            get { return Address; }
            set { Address = value; }
        }

        private string City;

        public string City1
        {
            get { return City; }
            set { City = value; }
        }

        private long Phone;

        public long Phone1
        {
            get { return Phone; }
            set { Phone = value; }
        }

        private double CreditLimit;

        public double CreditLimit1
        {
            get { return CreditLimit; }
            set { CreditLimit = value; }
        }
        //double CreditCutOff;
        public Customer()
        {
            double CreditCutOff = 50000;

                
        }
        public Customer(int CID,string Cname,string Add,string city,long phno,double cred)
        {
            CustomerId1 = CID;
            CustomerName1 = Cname;
            Address1 = Add;
            City1 = city;
            Phone1 = phno;
            CreditLimit1 = cred;
        }

      

                //c[i] = new Customer(CID,Cname,Add,city,phno,cred);



            
          


        
    }
}
