﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Class11._2;

namespace _11._1Console
{
    class Program
    {
        static void Main(string[] args)
        {
            CreditCard cd = new CreditCard();
            Console.WriteLine("Enter Credit Card No");
            cd.CreditCardNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Credit Card Name");
            cd.CardHolderName = Console.ReadLine();


            string choice1;

            do
            {
                Console.WriteLine("Enter your Choice \n1.GetBalance \n2.GetCreditLimit" +
                    "\n3.MakePayment \n4.Exit");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("Balance in your account is:" + cd.GetBalance());
                        break;
                    case 2:
                        Console.WriteLine("Credit Limit for your account is:" + cd.GetCreditLimit());

                        break;
                    case 3:
                        Console.WriteLine("Enter amount to credit");
                        double amount = Convert.ToDouble(Console.ReadLine());
                        cd.PaymentSuccessful += new MakePaymentHandler(CatchEvent);
                        cd.MakePayment(amount, "Payment Successfully Done");

                        break;
                    case 4:
                        return;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("Do you want to contiue(y/n)?");
                choice1 = Console.ReadLine();
            } while ((choice1 == "y"));
            Console.Read();
        }
        public static void CatchEvent(string s)
        {
            Console.WriteLine("Entered amount is credited");
        }

    }

}