﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArthameticOperations1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            Console.Write("Enter 1st numbers:");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter 2nd numbers:");
            b = Convert.ToInt32(Console.ReadLine());
            ArthmeticDelegate d = new ArthmeticDelegate(ArithematicOperations.Add);
            Console.WriteLine("Addition:" + d(a, b));
            d += new ArthmeticDelegate(ArithematicOperations.Sub);
            Console.WriteLine("Subtraction:" + d(a, b));
            d += new ArthmeticDelegate(ArithematicOperations.Mul);
            Console.WriteLine("Multiplication:" + d(a, b));
            d += new ArthmeticDelegate(ArithematicOperations.Div);
            Console.WriteLine("Division:" + d(a, b));
            d += new ArthmeticDelegate(ArithematicOperations.Max);
            Console.WriteLine("Maximum:" + d(a, b));
            Console.ReadKey();

        }
    }
}
