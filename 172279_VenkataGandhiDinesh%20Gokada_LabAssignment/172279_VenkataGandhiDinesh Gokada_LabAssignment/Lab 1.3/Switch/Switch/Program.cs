﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Switch
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.WriteLine("Enter a number :");
            n = int.Parse(args[0]);
            switch(n)
            {
                case 1:
                    Console.WriteLine("Iam one message");
                    break;
                case 2:
                    Console.WriteLine("Iam two message");
                    break;
                case 3:
                    Console.WriteLine("Iam three message");
                    break;
                case 4:
                    Console.WriteLine("Iam four message");
                    break;
                case 5:
                    Console.WriteLine("Iam five message");
                    break;
                default:
                    Console.WriteLine("Iam error message");
                    break;
                   


            }
            Console.ReadKey();
        }
    }
}
