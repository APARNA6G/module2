﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Struct
{
    class Program
    {
        

        struct Structrues
            {

                public  double square(double p)
                     {
                            double r = p * p;
                            return r;
                      }
                public double cube(double p)
                      {
                                double l = p * p * p;
                                return l;
                                

                      }

            }
        static void Main(string[] args)
        {
            Console.WriteLine("enter a number:");
            double p = Convert.ToDouble(Console.ReadLine());
            Structrues s = new Structrues();
            Console.WriteLine("enter 1 to perform Squre operation:");
            Console.Write("enter 2 to perform Cube operation:");
            int g = Convert.ToInt32(Console.ReadLine());
            if (g==1)
            {
                Console.WriteLine($"Square of {p} is: {s.square(p)}");
            }
            else
            {
                if(g==2)
                {
                    Console.WriteLine($"Cube of {p} is : {s.cube(p)}");
                }
                else
                {
                    Console.WriteLine( "enter valid number either 1 or 2 to perform operation:");
                }
            }

            
            
            
            

       
        }
    }
}
