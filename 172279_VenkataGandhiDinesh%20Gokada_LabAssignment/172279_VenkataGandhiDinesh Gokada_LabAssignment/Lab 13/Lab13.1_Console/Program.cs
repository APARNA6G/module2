﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using SerializeClassLib;
using System.Runtime.Serialization.Formatters.Binary;

namespace Lab13._1_Console
{
    class Program
    {

        static List<Contact> contact = new List<Contact>();
        private static string label6;

        static void Main(string[] args)
        {
            Contact con = new Contact();
            AddContact();
            DisplayContact();
            BinaryFormatter bf = new BinaryFormatter();
            FileStream fsout = new FileStream("Contact.txt",FileMode.Create, FileAccess.Write, FileShare.None);

            bf.Serialize(fsout, con);
            try
            {
                using (fsout)
                {
                    bf.Serialize(fsout, con);
                }
            }
            catch
            {
                label6 = "An error has occured";
            }

           // Console.WriteLine("Object Serialization is done ");
            Console.ReadLine();
        }
        static void AddContact()
        {
            Contact con = new Contact();
            Console.WriteLine("enter contact id:");
            con.ContactNo = int.Parse(Console.ReadLine());
            Console.WriteLine("enter contact name: ");
            con.ContactName = Console.ReadLine();
            Console.WriteLine("enter cell no: ");
            con.CellNo = Console.ReadLine();
            contact.Add(con);
        }
        static void DisplayContact()
        {
            List<Contact> cont = contact;
            Console.WriteLine("no   name   cell");
            foreach (Contact c in cont)
            {
                Console.WriteLine(c.ContactNo + " " + c.ContactName + " " + c.CellNo);
            }
        }                     
    }
}

