﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

 //we have done this program using reflections 
 //Reflection is ability to find information about types contained in an assembly at run time

namespace Reflection
{
    class Person
    {
        
        private string name;
        public string Name { get; set; }
        private int age;
        public int Age { get; set; }
        private float salary;
        public float Salary { get; set; }
       
        // creating a constructor

       
        public Person(String Name, int Age, float Salary)
        {
            name = Name;
            age = Age;
            salary = Salary;
        }
    }
    public class Example
    {
        public static void Main()
        {
            Person person = new Person("DINESH", 22, 30000);
            GetPropertyValues(person);
            Console.ReadLine();
        }
        private static void GetPropertyValues(Object obj)
        {
            Type t = obj.GetType();
            Console.WriteLine("Type is: {0}", t.Name);
           
            // here we are using propertyinfo
         
            PropertyInfo[] props = t.GetProperties();
            foreach (var prop in props)
                if (prop.GetIndexParameters().Length == 0)
                    Console.WriteLine(" {0} ({1}): {2}", prop.Name,prop.PropertyType.Name,prop.GetValue(obj));
                else
                    Console.WriteLine(" {0} ({1}): <Indexed>", prop.Name,prop.PropertyType.Name);

        }

    }
}
    
