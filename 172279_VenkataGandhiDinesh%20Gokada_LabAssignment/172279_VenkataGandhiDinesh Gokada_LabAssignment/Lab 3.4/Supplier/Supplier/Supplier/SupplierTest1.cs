﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supplier
{
    class SupplierTest1
    {
       
        int supplierID;
        string supplierName;
        string city;
        string phoneNumber;
        string email;
        public void   AcceptDetails()
        {
            Console.WriteLine("Enter Supplier ID:");
            int n = Convert.ToInt32(Console.ReadLine());
            supplierID = n;
            Console.WriteLine("Enter Supplier Name:");
            string s = Console.ReadLine();
            supplierName = s;
            Console.WriteLine("Enter city:");
            string k = Console.ReadLine();
            city = k;
            Console.WriteLine("Enter Phone Number:");
            string t = Console.ReadLine();
            phoneNumber = t;
            Console.WriteLine("Enter email:");
            string j = Console.ReadLine();
            email = j;

        }
        public void DisplayDetails()
        {
            Console.WriteLine($"Supplier ID is:{supplierID}");
            Console.WriteLine($"Supplier Name is :{supplierName}");
            Console.WriteLine($"Supplier City is : {city}");
            Console.WriteLine($"Supplier Phone Number: {phoneNumber}");
            Console.WriteLine($"Supplier email is: {email}");
        }

    }
}
